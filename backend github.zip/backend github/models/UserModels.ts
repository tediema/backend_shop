import {DB} from "../core/DB"

export class UserModel extends DB {

    async getAllUsers(){
        try {
            const [rows] = await this.conn.query("SELECT * FROM users");
            console.log({ rows });
            return rows
            
        }
        catch (e) {
            const error= e as Error;
            throw new Error(error.message)
        }
    }
}