import { UserModel } from "../models/UserModels";
import { Request, Response } from "express";

export class UserController{
    private userModel: UserModel
    constructor(){
        this.userModel= new UserModel()
    }

    async getAllUsers(req: Request, res: Response){
        const users= await this.userModel.getAllUsers()
        res.send(users)
    }
}