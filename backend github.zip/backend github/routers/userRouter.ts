import {Request, Response, Router} from "express";
import { UserController } from "../controllers/UserController";

export const userRouter = Router()

const userController= new UserController()

const getAllUsersHandler = async (req: Request, res: Response)=>{
 await userController.getAllUsers(req,res)
}

userRouter.get("/users", getAllUsersHandler)
userRouter.get("/users/:id", getAllUsersHandler)