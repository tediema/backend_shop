import mysql2 from "mysql2"

export class DB {
    conn;

    constructor(){
        this.conn = mysql2.createPool({
            host: "localhost",
            database: "online_shop",
            user: "root",
            password: ""
        }).promise();
    }
}