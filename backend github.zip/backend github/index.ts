import express from "express"
import { userRouter } from "./routers/userRouter";

const app = express()

// app.use(json())
app.use(userRouter)



// app.post("/", async(req: Request, res: Response)=>{
//     const data = req.body;
//     const size=data.size 
//     const price=data.price
//     const gender=data.gender
//     // const username= data.username
//     // const createdAt=data.createdAt
//     // const password=data.password
//     const [rows] = await conn.execute(
//         `INSERT INTO jeans (size, price, gender) VALUES(?,?,?)`, [size,price,gender]
//     )
    
//     res.send({
//         message: "Successfully created jeans"
//     })
// })

app.listen( 3000, ()=>{
    console.log(("started!"));
    
})